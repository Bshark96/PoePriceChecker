// Trade Controller Constructor
function TradeController(tradeCardRenderer) {
  this.cardRenderer = tradeCardRenderer || new TradeCardRenderer();
  this.activeSearchUrl = null;
}

TradeController.prototype.triggerSearch = function() {
  var isGameBar = window.PoeBridge && window.PoeBridge.isGameBarHost();
  var presetKey = window.itemController ? window.itemController.currentPresetKey : 'chambers';

  if (window.PoeBridge) {
    window.PoeBridge.notifyHost({ action: 'search', preset: presetKey });
  }

  var loader = document.getElementById('searchLoadingBar');
  var listEl = document.getElementById('resultsList');
  if (loader) loader.classList.remove('is-hidden');
  if (listEl) listEl.style.opacity = '0.3';

  if (!isGameBar) {
    // Standalone browser preview: simulate mock response
    var self = this;
    setTimeout(function() {
      if (loader) loader.classList.add('is-hidden');
      if (listEl) listEl.style.opacity = '1';
      self.renderSearchResults(presetKey);
    }, 250);
  }
};

TradeController.prototype.renderSearchResults = function(key) {
  var listEl = document.getElementById('resultsList');
  if (!listEl) return;

  var rawList = (marketListings[key] || []).slice();
  var sortSelect = document.getElementById('resultsSort');
  var sortMode = (sortSelect && sortSelect.value) ? sortSelect.value : 'price-asc';

  var listings = rawList.map(function(item) {
    return new TradeListingModel(item);
  });

  if (sortMode === 'price-asc') {
    listings.sort(function(a, b) {
      return a.getNormalizedPriceInChaos() - b.getNormalizedPriceInChaos();
    });
  } else if (sortMode === 'price-desc') {
    listings.sort(function(a, b) {
      return b.getNormalizedPriceInChaos() - a.getNormalizedPriceInChaos();
    });
  }

  var countEl = document.getElementById('resultsCount');
  if (countEl) countEl.innerText = listings.length + ' LISTINGS';

  var preset = dataPresets[key] || dataPresets.chambers;
  listEl.innerHTML = '';

  var self = this;
  listings.forEach(function(listing) {
    var card = self.cardRenderer.createCardElement(listing, preset);
    listEl.appendChild(card);
  });
};

TradeController.prototype.renderTradeResultsData = function(data) {
  var listEl = document.getElementById('resultsList');
  var countEl = document.getElementById('resultsCount');

  if (countEl && data.totalCount !== undefined) {
    countEl.innerText = data.totalCount + ' LISTINGS';
  }
  if (!listEl || !Array.isArray(data.listings)) return;

  listEl.innerHTML = '';
  var self = this;
  data.listings.forEach(function(item) {
    var listing = new TradeListingModel(item);
    var card = self.cardRenderer.createCardElement(listing, { name: listing.itemName, nameColor: '#f7d070' });
    listEl.appendChild(card);
  });
};

TradeController.prototype.toHideout = function(seller) {
  var cmd = '/hideout ' + seller;
  if (window.PoeBridge) {
    window.PoeBridge.notifyHost({ action: 'hideout', seller: seller, command: cmd });
    window.PoeBridge.showToast('Copied to clipboard: ' + cmd);
  }
};

TradeController.prototype.whisperSeller = function(seller, char, priceVal, priceType) {
  var p = dataPresets[window.itemController ? window.itemController.currentPresetKey : 'chambers'];
  var itemStr = (p && p.name) ? p.name : 'item';
  var whisperText = '@' + seller + ' Hi, I would like to buy your ' + itemStr + ' listed for ' + priceVal + ' ' + priceType + ' in Settlers (stash tab "~b/o ' + priceVal + ' ' + priceType + '")';

  if (window.PoeBridge) {
    window.PoeBridge.notifyHost({
      action: 'whisper',
      seller: seller,
      character: char,
      text: whisperText,
      price: priceVal,
      currency: priceType
    });
    window.PoeBridge.showToast('Whisper copied: @' + seller + ' (' + priceVal + ' ' + priceType + ')');
  }
};
